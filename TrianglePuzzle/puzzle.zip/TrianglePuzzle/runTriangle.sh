#!/bin/bash
java -jar triangle.jar triangle.txt
read -n1